#ifndef	__TASK_TIMING_REPORT_H
#define	__TASK_TIMING_REPORT_H

#include "sys.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"

extern QueueHandle_t CAN1_Queue;	// CAN1��Ϣ���о��
extern QueueHandle_t CAN2_Queue;	// CAN2��Ϣ���о��

void Timer_Send_Create(void);

#endif

