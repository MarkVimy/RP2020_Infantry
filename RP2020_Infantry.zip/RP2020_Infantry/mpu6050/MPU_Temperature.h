#ifndef Temperature_H
#define Temperature_H

#include "system.h"

void MPU_TempPID_Init_IO(void);
void Tempeture_PID(void);

#endif
