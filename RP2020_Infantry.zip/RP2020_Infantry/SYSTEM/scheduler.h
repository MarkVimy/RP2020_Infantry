#ifndef __SCHEDULER_H
#define __SCHEDULER_H

#include "init.h"

void start_task(void *pvParameters);	// ������

#endif


