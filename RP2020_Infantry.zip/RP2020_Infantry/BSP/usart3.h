#ifndef __USART3_H
#define __USART3_H

/* Includes ------------------------------------------------------------------*/
#include "sys.h"

/* Global macro --------------------------------------------------------------*/

/* Global TypeDef ------------------------------------------------------------*/
/* ## Global Variables Prototypes ## -----------------------------------------*/

/* API functions Prototypes --------------------------------------------------*/
void USART3_Init( void );
void USART3_SendChar( uint8_t cData );

#endif
