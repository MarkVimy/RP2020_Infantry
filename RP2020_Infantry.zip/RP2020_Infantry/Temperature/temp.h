#ifndef __TEMP_H
#define __TEMP_H

#include "sys.h"

void MPU_TempPID_Init_IO(void);
void Tempeture_PID(void);


#endif
