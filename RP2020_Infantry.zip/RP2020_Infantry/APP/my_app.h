#ifndef __MY_APP_H
#define __MY_APP_H

/* App Info */
#include "judge.h"
#include "vision.h"

/* App */
#include "remote.h"
#include "friction.h"
#include "magzine.h"
#include "ultra.h"
#include "anoc.h"

#endif
